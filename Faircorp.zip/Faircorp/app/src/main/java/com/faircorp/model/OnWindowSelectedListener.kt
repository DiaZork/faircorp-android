package com.faircorp.model

interface OnWindowSelectedListener {
    fun onWindowSelected(id: Long)
}