package com.faircorp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class MenuWindows : BasicActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu_windows)
    }
}